# LCD-ATMEGA16
- Display String/Char to LCD 16x2 by ATMEGA16
- Video Demo : https://youtu.be/zWRkk4m4CX0
